---
name: bpmn-diagram-renderer
description: "Render BPMN 2.0 XML diagrams to SVG/PNG using bpmn-js + Chromium headless — identical output to Camunda Modeler."
trigger: User asks to render a BPMN diagram, export BPMN to image, or visualize a .bpmn file.
related_skills: [html-to-pdf-chromium]
---

# BPMN Diagram Renderer

Renderiza diagramas BPMN 2.0 (arquivos `.bpmn`) em SVG e PNG usando **bpmn-js** — a mesma biblioteca que o Camunda Modeler usa internamente. Output indistinguível do Camunda.

## Por que bpmn-js e não Python

- bpmn-js renderiza pools, lanes, gateways com gutter interno, edge routing com waypoints curvos, message flows tracejados, ícones de eventos — tudo exatamente como o Camunda Modeler.
- Alternativas Python (drawsvg, graphviz) levariam semanas e nunca alcançariam a mesma fidelidade.
- O Chromium headless já está instalado no ambiente (ver `html-to-pdf-chromium`).

## Setup (uma vez por workspace)

```bash
cd /tmp/bpmn-test
npm init -y
PUPPETEER_SKIP_DOWNLOAD=true npm install bpmn-js puppeteer
```

`PUPPETEER_SKIP_DOWNLOAD=true` evita baixar outro Chromium (já temos o do Debian extraído).

## Renderizar um BPMN

### 1. Baixar o `.bpmn` do Google Drive (ou ler do disco)

```python
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import io

creds = service_account.Credentials.from_service_account_file(
    'path/to/service_account.json',
    scopes=['https://www.googleapis.com/auth/drive']
)
drive = build('drive', 'v3', credentials=creds)

request = drive.files().get_media(fileId='<FILE_ID>')
fh = io.BytesIO()
downloader = MediaIoBaseDownload(fh, request)
done = False
while not done:
    _, done = downloader.next_chunk()

with open('diagram.bpmn', 'w') as f:
    f.write(fh.getvalue().decode('utf-8'))
```

### 2. Script Node.js de renderização

Criar `render.js`:

```javascript
const puppeteer = require('puppeteer');
const fs = require('fs');

const bpmnXML = fs.readFileSync('diagram.bpmn', 'utf8');
const bpmnJS = fs.readFileSync('node_modules/bpmn-js/dist/bpmn-viewer.production.min.js', 'utf8');

const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #fff; }
  #canvas { width: 1200px; height: 800px; }
</style>
</head>
<body>
<div id="canvas"></div>
<script>${bpmnJS}</script>
<script>
  var viewer = new BpmnJS({ container: '#canvas' });
  var xml = ${JSON.stringify(bpmnXML)};
  viewer.importXML(xml).then(function() {
    viewer.get('canvas').zoom('fit-viewport');
    window.__BPMN_READY__ = true;
  }).catch(function(err) {
    document.body.textContent = 'Error: ' + err.message;
  });
</script>
</body>
</html>`;

fs.writeFileSync('diagram.html', html);

(async () => {
  const browser = await puppeteer.launch({
    executablePath: '/tmp/chromium-extracted/usr/lib/chromium/chromium',
    args: ['--no-sandbox', '--disable-gpu', '--disable-software-rasterizer'],
    headless: true
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1200, height: 800, deviceScaleFactor: 2 });
  await page.goto('file://' + __dirname + '/diagram.html', { waitUntil: 'networkidle0', timeout: 30000 });
  await page.waitForFunction('window.__BPMN_READY__ === true', { timeout: 15000 });
  await new Promise(r => setTimeout(r, 1000));

  // PNG screenshot
  await page.screenshot({ path: 'diagram.png', fullPage: true });
  console.log('diagram.png salvo');

  // SVG export
  const svg = await page.evaluate(() => {
    const el = document.querySelector('#canvas svg');
    return el ? el.outerHTML : null;
  });
  if (svg) {
    fs.writeFileSync('diagram.svg', svg);
    console.log('diagram.svg salvo (' + svg.length + ' bytes)');
  }

  await browser.close();
})();
```

### 3. Executar

```bash
cd /tmp/bpmn-test
LD_LIBRARY_PATH=/tmp/chromium-extracted/usr/lib/chromium node render.js
```

O `LD_LIBRARY_PATH` aponta para as `.so` extraídas do Chromium Debian.

## Output

- `diagram.svg` — SVG vetorial (editável, ~15-20KB para diagramas típicos)
- `diagram.png` — Screenshot 2x retina (~70-100KB)

Ambos com fidelidade Camunda: fontes, espaçamento, bordas, conectores, swimlanes — tudo idêntico.

## Pitfalls

- **ES modules (`import ... from 'bpmn-js'`) não funcionam no browser.** Usar SEMPRE o bundle UMD (`bpmn-viewer.production.min.js`) com tag `<script>` inline.
- **`LD_LIBRARY_PATH` ausente** → Chromium aborta com `libopenh264.so.8: cannot open shared object file`.
- **`PUPPETEER_SKIP_DOWNLOAD=true`** é obrigatório no `npm install` para não tentar baixar outro Chromium (o Debian extraído já cobre).
- **Viewport maior que o diagrama** → usar `canvas.zoom('fit-viewport')` para ajustar automaticamente.
- **BPMN com colaboração (pools)** → bpmn-js lida nativamente; não requer configuração extra.
- **Timeout de 15s** no `waitForFunction` é suficiente para BPMNs de até ~200 elementos. Diagramas maiores podem precisar de 30s.

## Integração com Dédalo Squad

O renderizador é standalone (Node.js), não acoplado ao pipeline Python. Para integrar:

```python
import subprocess, os
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = '/tmp/chromium-extracted/usr/lib/chromium'
subprocess.run(['node', '/tmp/bpmn-test/render.js'], cwd='/tmp/bpmn-test', env=env, check=True)
# Output: /tmp/bpmn-test/diagram.svg + diagram.png
```

Basta o `.bpmn` estar em `/tmp/bpmn-test/diagram.bpmn` antes de chamar.
