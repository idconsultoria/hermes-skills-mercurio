const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const bpmnFile = process.argv[2] || 'diagram.bpmn';
const bpmnXML = fs.readFileSync(bpmnFile, 'utf8');
const bpmnJS = fs.readFileSync(
  path.join(__dirname, '..', '..', '..', '..', 'tmp', 'bpmn-test', 'node_modules', 'bpmn-js', 'dist', 'bpmn-viewer.production.min.js'),
  'utf8'
);

const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #fff; }
  #canvas { width: 1200px; height: 800px; }
</style>
</head>
<body>
<div id="canvas"></div>
<script>${bpmnJS}</script>
<script>
  var viewer = new BpmnJS({ container: '#canvas' });
  var xml = ${JSON.stringify(bpmnXML)};
  viewer.importXML(xml).then(function() {
    viewer.get('canvas').zoom('fit-viewport');
    window.__BPMN_READY__ = true;
  }).catch(function(err) {
    document.body.textContent = 'Error: ' + err.message;
    console.error(err);
  });
</script>
</body>
</html>`;

fs.writeFileSync('diagram.html', html);

(async () => {
  const browser = await puppeteer.launch({
    executablePath: '/tmp/chromium-extracted/usr/lib/chromium/chromium',
    args: ['--no-sandbox', '--disable-gpu', '--disable-software-rasterizer'],
    headless: true
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1200, height: 800, deviceScaleFactor: 2 });

  page.on('console', msg => console.log('BROWSER:', msg.text()));
  page.on('pageerror', err => console.log('PAGE ERROR:', err.message));

  const fileUrl = 'file://' + process.cwd() + '/diagram.html';
  console.log('Loading:', fileUrl);
  await page.goto(fileUrl, { waitUntil: 'networkidle0', timeout: 30000 });

  await page.waitForFunction('window.__BPMN_READY__ === true', { timeout: 15000 });
  await new Promise(r => setTimeout(r, 500));

  // Screenshot
  await page.screenshot({ path: 'diagram.png', fullPage: true });
  const pngStat = fs.statSync('diagram.png');
  console.log(`diagram.png saved (${(pngStat.size / 1024).toFixed(0)}KB)`);

  // SVG export
  const svg = await page.evaluate(() => {
    const el = document.querySelector('#canvas svg');
    return el ? el.outerHTML : null;
  });
  if (svg) {
    fs.writeFileSync('diagram.svg', svg);
    console.log(`diagram.svg saved (${svg.length} bytes)`);
  } else {
    console.log('SVG not found in canvas');
  }

  await browser.close();
  console.log('Done.');
})();
