# BPMN 2.0 Rendering with bpmn-js + Chromium Headless

Uses the same Chromium setup from the html-to-pdf-chromium skill to render
BPMN 2.0 XML diagrams as PNG images via bpmn-js (the same engine that powers
Camunda Modeler).

## Project Integration (Dédalo Squad)

Found in `/opt/data/dedalo_squad/render/`:

```
render/
  package.json        # deps: bpmn-js + puppeteer
  render_bpmn.js      # node render_bpmn.js <input.bpmn> [output.png]
  setup.sh            # cd render && bash setup.sh
```

After `git clone`, run:
```bash
cd render && bash setup.sh    # installs bpmn-js + puppeteer, detects Chromium
```

## Chromium Detection Order

The render script auto-detects Chromium in this order:
1. `$PUPPETEER_EXECUTABLE_PATH` or `$CHROMIUM_PATH` env var
2. `/tmp/chromium-extracted/usr/lib/chromium/chromium` (Debian-extracted, aarch64 compatible)
3. Puppeteer's built-in Chromium (downloaded during `npm install`)

On aarch64 (Oracle ARM, Raspberry Pi): the Debian-extracted Chromium is required
because Puppeteer's default is x86_64. The script sets `LD_LIBRARY_PATH` to include
the extracted libs automatically.

## Python Wrapper

```python
from agemini.conectores.render_bpmn import renderizar_bpmn, renderizar_e_salvar_no_drive

# Render to bytes
png_bytes = renderizar_bpmn(bpmn_xml_string)

# Render + upload to Google Drive, returns shareable URL
url = renderizar_e_salvar_no_drive(bpmn_xml_string, drive_folder_id, "Estrategico")
```

## Architecture

Puppeteer launches Chromium, loads an HTML page with bpmn-js inlined (~180KB minified),
imports the BPMN XML, waits for `window.__BPMN_READY__`, and takes a fullPage screenshot
at 2x retina. The SVG is also extractable but currently only PNG is saved.

## Output Quality

Indistinguishable from Camunda Modeler — same bpmn-js library, same font rendering,
same shape primitives (rounded rects for tasks, circles for events, diamonds for gateways),
correct arrowhead markers, dashed message flows, pool/lane partitions.

## Pitfalls

- **bpmn-js UMD bundle must be inlined** — ES module imports don't work from file:// pages.
  Use `bpmn-viewer.production.min.js` from the dist/ folder.
- **Chromium on aarch64** — Puppeteer downloads x86_64 Chrome by default. On ARM machines,
  use the Debian-extracted Chromium from this skill's setup.
- **LD_LIBRARY_PATH** — the Debian Chromium needs `libopenh264.so.8` and friends.
  The render script sets this automatically when using the Debian path.
